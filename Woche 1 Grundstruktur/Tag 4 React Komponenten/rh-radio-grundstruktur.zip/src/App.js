//import logo from './logo.svg';
import './app.css';

/**
 * Baut die Internet Seite des Radiosenders
 * HipDipDauerwelle auf und gibt das zurueck.
 * 
 * @returns HTML-Code der WebApp
 */
function App() {


  function Header() {

    function CompanyName() {
      const nameOfTheCompany = "HipDipDauerwelle"
      const subTitleOfCompany = "Dein Radiosender auf Dauerwelle";

      return (
        <div className="company-name">
          <h1>{nameOfTheCompany}</h1>
          <p>{subTitleOfCompany}</p>
        </div>
      );
    }

    function TopNav() {
      return (
        <div className='top-nav'>
          <nav>
            <a href="/">Programm</a>
            <a href="/">Playlist</a>
            <a href="/">Werbung buchen</a>
            <a href="/">Team</a>
          </nav>
        </div>
      );
    }

    function EyeCatcher() {
      const currentPostHeaderText = "Samy Deluxe im Anmarsch"
      const currentPostTextTeaser = "Samy Delux hat eine neue Single veröffentlicht. Simon Desu produzierte die Beats"


      return (
        <div className="eye-catcher">
          <div className="current-post">
            <h2>{currentPostHeaderText}</h2>
            <p>{currentPostTextTeaser}<a href=" / ">weiterlesen</a></p>
          </div>
        </div>
      );
    }

    return (
      <header>
        <CompanyName />
        <TopNav />
        <EyeCatcher />
      </header>
    );
  }

  function MainContent() {

    function NewsPost() {
      return (
        <div className="news-post">
          <h3>Post 1</h3>
          <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
        </div>
      );
    }

    function CurrentNews() {
      return (
        <div className="current-news">
          <h2>Radio News</h2>

          <NewsPost />

          <NewsPost />

          <NewsPost />

          <NewsPost />
        </div>
      );
    }

    function BookCommercials() {
      return (
        <div className="book-commercials">
          <h2>Bei uns Werben</h2>
          <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>

          <div className="book-commercials-img">
            Bild
          </div>
        </div>
      );
    }

    return (
      <main>
        <CurrentNews />
        <BookCommercials />
      </main>
    );
  }

  function Footer() {
    function BottomNav() {
      return (
        <nav>
          <a href="/">Impressum</a>
          <a href="/">Datenschutz</a>
        </nav>
      );
    }

    return (
      <footer>

        <BottomNav />

      </footer>
    );
  }

  return (
    <div className="app">
      <Header />

      <MainContent />

      <Footer />

    </div >
  );
}

export default App;
