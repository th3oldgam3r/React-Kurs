//React Imports somit wird das hier zu einer React-Applikation
import React from 'react';
import ReactDOM from 'react-dom/client';

//Globale Styles laden
import './index.css';

//Laden der App Komponente
import App from './App';

//Startet und ueberwacht den Webserver welcher die Applikation betreibt
import reportWebVitals from './reportWebVitals';

//Root Element(div mit der id "root" aus der index.html) laden per ReactDom
const root = ReactDOM.createRoot(document.getElementById('root'));

/*
 * Render/Anzeige - Aufbaubefehl an das
 * root-Element baue alles per React auf und nutze
 * die React-Komponente App
 */
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

//Starte und ueberwache Webserver
reportWebVitals();
