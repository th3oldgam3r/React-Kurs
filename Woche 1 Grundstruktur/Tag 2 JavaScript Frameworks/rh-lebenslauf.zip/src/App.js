//Styles fuer diese Komponente importieren
import './App.css';

/**
 * Funktionale React Komponente mit dem Namen App
 * Die Baut Header, Main, Footer auf und liefert alles
 * als HTML-Code zurueck.
 */
function App() {
  //Personendaten
  const cvPersonName = "Rudolf Histel"
  const cvPersonBday = "17.06.1990"
  const cvPersonAddress = "Bürgermeister-Regitz-Straße 40 66538 Neunkirchen"


  /**
   * Interne Funktionale Komponente
   * @returns Applikationsheader mit Ueberschrift
   */
  function AppHeader() {
    return (
      <header className="App-header">
        {/*Nutzen von Komonenten Werten/Objekten etc.*/}
        <h1>{cvPersonName} Lebenslauf</h1>
      </header>
    );
  }

  /**
   * Interne Funktionale Komponente
   * Baut den Hauptinhalt auf.
   * 
   * @returns HTML-Code fuer den Hauptinhalt zurueck
   */
  function AppMainContent() {

    /**
     * MainContent interne Komponente PersonalData->MainContent->App
     * @returns  Generierter/Gerendert HTML-Code
     */
    function PersonalData() {
      return (
        <div>
          <h2>Persönliche Daten</h2>
          <p>Name:<br></br> {cvPersonName}</p>
          <p>Geburtstag:<br></br> {cvPersonBday}</p>
          <p>Anschrift:<br></br> {cvPersonAddress}</p>
        </div>
      );
    }

    /**
     * MainContent interne Komponente PersonalData->MainContent->App
     * @returns  Generierter/Gerendert HTML-Code
     */
    function JobExperience() {
      return (
        <div>
          <h2>Berufliche Erfahrung</h2>

          <h3>Ausbildung</h3>
          <p>Fachinfomratiker für Anwendungsentwicklung</p>

          <h3>Selbständig IT-Fullservice Agentur mission-webstyle oHG</h3>
          <p>Geschäftsführer</p>

        </div>
      );
    }

    return (
      <main>
        {/* Hook-Call Interne Komponente MainContent->PeronalData ohne Parameter */}
        <PersonalData />
        {/* Hook-Call Interne Komponente MainContent->JobExperience ohne Parameter */}
        <JobExperience />
      </main>
    );
  }

  /**
   * Interne Komoponente
   * Funktionale Komponente baut den Footer auf.
   * @returns Generierter HTML-Code fuer den Footer
   */
  function AppFooter() {
    return (
      <footer className="App-footer">
        <a href='/'>Impressum</a><a href='/'>Datenschutz</a><a href='/'>Kontakt</a>
        <p>Telefon: 06821/1234</p>
      </footer>
    );
  }

  /*
   * Rendert und liefert das generierte HTML
   * <AppHeader/> HookCall
   * an den Aufrufer zurueck App.js->index.js->index.html
   */
  return (
    <div className="App">
      {/* Hook-Call Interne Komponente AppHeader ohne Parameter */}
      <AppHeader />

      {/* Hook-Call Interne Komponente MainContent ohne Parameter */}
      <AppMainContent />

      {/* Hook-Call Interne Komponente AppFooter ohne Parameter */}
      <AppFooter />
    </div>
  );
}

//Komponente wird nach aussen erreichbar
export default App;
