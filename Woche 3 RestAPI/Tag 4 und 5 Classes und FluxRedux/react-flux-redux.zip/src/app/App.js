
import React from "react"
import { useDispatch } from 'react-redux'
import MoneyDisplay from "../components/MoneyDisplay";

import '../styles/app.css';

import { decrement, increment } from "../components/moneySlice";

/**
 * Ein Geld Spiel,
 * welches dem Spieler suggeriert
 * durch inkrementierung und dekrementierung
 * einen bestimmten Geldbetrat zu erreichen, um dann einen
 * hoeheren Betrag zu gewinnen. Dieser kann jedoch nur erreicht
 * werden sollte das Geldfeld angeklickt werden.
 */
function App() {

  const dispatch = useDispatch();

  return (
    <div className="App">
      <header className="App-header">
        <h1>Spiel des Geldes</h1>
      </header>
      <main>
        <h2>Starte das Spiel mit + oder -</h2>
        <p>Erreiche einen Betrag größer als 10 € und gewinne 1.000.000 €</p>

        <MoneyDisplay />

        <button onClick={() => dispatch(decrement())}>-</button>
        <button onClick={() => dispatch(increment())}>+</button>

      </main >
    </div >
  );
}

export default App;
