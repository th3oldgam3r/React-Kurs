import { configureStore } from '@reduxjs/toolkit'
import moneyReducer from '../components/moneySlice'

export const store = configureStore({
    reducer: {
        money: moneyReducer,
    },
})