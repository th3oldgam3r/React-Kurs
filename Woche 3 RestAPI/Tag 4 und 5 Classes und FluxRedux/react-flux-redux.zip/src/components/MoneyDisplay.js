import React from 'react'
import "../styles/app.css"
import { useSelector, useDispatch } from 'react-redux'
import { setAmount } from './moneySlice'

/**
 * Nutz redux um den aktuellen Betrag anzuzeigen,
 * welcher Projektglobal zur Verfuegung steht.
 * 
 * Triggert das setzen des Gewinnbetrages.
 * 
 * Alle Werte werden automatisch ueberwacht und aktualisiert.
 * 
 * @returns Zeigt in ein P-Tag den akutellen Geldbetrag an
 */
export default function MoneyDisplay() {

    const winningAmount = 1000000

    //Anzeige des Wertes
    const money = useSelector((state) => state.money.value)

    //Aendern des Wertes ueber eine Aktion
    const dispatch = useDispatch()

    return (
        <p className="current-amount-of-money" onClick={() => dispatch(setAmount(winningAmount))}>{money} ,-</p>
    )
}