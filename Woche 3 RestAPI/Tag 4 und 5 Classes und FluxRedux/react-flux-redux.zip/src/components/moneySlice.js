import { createSlice } from '@reduxjs/toolkit'

const initialState = {
    value: 0,
}

export const counterSlice = createSlice({
    name: 'money',
    initialState,
    reducers: {
        increment: (state) => {
            const incrementedValue = state.value + 1
            if (incrementedValue === 10) {
                state.value = 0;
            } else {
                state.value += 1
            }
        },
        decrement: (state) => {
            const decrementedValue = state.value - 1
            if (decrementedValue < 0) {
                state.value = -10
            } else {
                state.value -= 1
            }
        },
        setAmount: (state, action) => {
            state.value = action.payload
        },
    },
})

// Action creators are generated for each case reducer function
export const { increment, decrement, setAmount } = counterSlice.actions

export default counterSlice.reducer