import mySql from "mysql"

export function getNewsArticles() {
    return async (requestToServer, responseToClient) => {
        const dbConnection = mySql.createPool(
            {
                connectionLimit: 10,
                password: '',
                user: 'root',
                database: 'rh_radio',
                host: 'localhost',
                port: '3306'
            }
        )

        dbConnection.query("SELECT * FROM news_articles",
            (error, newsArticlesFromDB) =>{
                if(error){
                    console.log(error)
                }

                console.log(newsArticlesFromDB)
                responseToClient.send(newsArticlesFromDB)
            }
        )

    };
}

export function getNewsArticle() {
    return async (requestToServer, responseToClient) => {

        const dbConnection = mySql.createPool(
            {
                connectionLimit: 10,
                password: '',
                user: 'root',
                database: 'rh_radio',
                host: 'localhost',
                port: '3306'
            }
        )

        dbConnection.query(`SELECT * FROM news_articles WHERE news_id = ${requestToServer.params.news_id}`,
            (error, newsArticlesFromDB) =>{
                if(error){
                    console.log(error)
                }

                console.log(newsArticlesFromDB)
                responseToClient.send(newsArticlesFromDB)
            }
        )
    };
}