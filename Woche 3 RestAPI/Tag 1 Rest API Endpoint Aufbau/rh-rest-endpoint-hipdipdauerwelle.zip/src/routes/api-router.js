import express from "express"
import {
    getNewsArticles,
    getNewsArticle
} from "../controller/news-articles.js";

const apiRouter = express.Router();

const newsArticlesPath = "/news-articles";
const newsArticlesPathWithParameterNewsId = "/news-articles/:news_id";

const employeesPath = "/employees";
const employeesPathWithParameterEmployeeId = "/employees/:employeeId";




apiRouter.get(newsArticlesPath,  getNewsArticles())
apiRouter.get(newsArticlesPathWithParameterNewsId,  getNewsArticle())

export default apiRouter;