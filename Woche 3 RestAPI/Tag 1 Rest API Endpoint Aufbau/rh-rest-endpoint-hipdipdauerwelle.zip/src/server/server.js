
/**
 * Ermoeglicht die Konfiguration eines
 * Ports und dessen konfiguration und Ueberwachung
 * @type {e | (() => Express)}
 */
import express, {response} from "express"

/**
 * Router welche auf einem
 * gesetzten Pfad die GET,POST,PUT - und DELETE-Anfragen
 * verarbeitet und passende Anfragen an die Datenbank
 * triggert
 */
import apiRouter from "../routes/api-router.js"

/**
 * Erlaubt das konfigurieren von Applikationen
 * die auf diese REST-API zugreifen duerfen
 */
import cors from "cors"
/**
 * Expressobjekt welches fuer
 * die passenden Routes und Ueberwachung
 * konfiguriert und ausgefuehrt wird
 * @type {Express}
 */
const serverApplication = express();

const APPLICATION_PORT = 3003
const HOST_NAME = "localhost"
const MAX_ALLOWED_CONNECTIONS = 20;

const APPLICATION_HEADER = `
    ##################################
    # HipDipDauerwelle - REST-Server #
    ##################################
    
    Staus: gestartet
    Link: http://localhost:${APPLICATION_PORT}
    `
const welcomeMessage = "Willkommen zum REST-Endpoint von HipDipDauerwelle :D";


//Festlegen das die Hauptdatenkommunikation per JSON funktionieren wird
const allowedOrigin = "http://localhost:3000"
serverApplication.use(cors({
    origin: allowedOrigin
}));

//Festlegen das die Hauptdatenkommunikation per JSON funktionieren wird
serverApplication.use(express.json())

//Kommt eine GET-Anfrage auf die Root-URL http://localhost:3003 Willkommensnachricht senden
serverApplication.get("/",(requestToServer,responseToClient)=>responseToClient.send(welcomeMessage))
serverApplication.use("/api",apiRouter)

//Portueberwachung anschalten und nach obiger Konfiguration ausfuehren
serverApplication.listen(
    (process.env.PORT || APPLICATION_PORT),
    HOST_NAME,
    MAX_ALLOWED_CONNECTIONS,
    ()=>{
        console.log(APPLICATION_HEADER)
    }
)