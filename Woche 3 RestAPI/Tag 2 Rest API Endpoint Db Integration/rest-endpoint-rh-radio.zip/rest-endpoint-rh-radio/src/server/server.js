/**
 * Ermoeglicht die Konfiguration eines
 * Ports und dessen konfiguration und Ueberwachung
 * @type {e | (() => Express)}
 */
import express from "express"
import cors from "cors"

/**
 * Router welche auf einem
 * gesetzten Pfad die GET,POST,PUT - und DELETE-Anfragen
 * verarbeitet und passende Anfragen an die Datenbank
 * triggert
 */
import apiRouter from "../routes/api-router.js"

/**
 * Expressobjekt welches fuer
 * die passenden Routes und Ueberwachung
 * konfiguriert und ausgefuehrt wird
 * @type {Express}
 */
const serverApplication = express()

const APPLICATION_PORT = 3001
const HOST_NAME = "localhost"
const MAX_ALLOWED_CONNECTIONS = 20;

const applicationHeader = `
    ##################################
    # HipDipDauerwelle - REST-Server #
    ##################################
    
    Staus: gestartet
    Link: http://localhost:${APPLICATION_PORT}
`
const welcomeMessage = "Willkommen zum REST-Endpoint von HipDipDauerwelle :D";


//Festlegen das die Hauptdatenkommunikation per JSON funktionieren wird
const allowedOrigin = "http://localhost:3000"
serverApplication.use(cors({
    origin: allowedOrigin
}));
serverApplication.use(express.json())

serverApplication.get("/", (requestToServer,responseToClient) =>  responseToClient.send(welcomeMessage))
serverApplication.use("/api",apiRouter)


//Portueberwachung anschalten und nach obiger Konfiguration ausfuehren
serverApplication.listen(
    (process.env.PORT || APPLICATION_PORT),
    HOST_NAME,
    MAX_ALLOWED_CONNECTIONS,
    () => {
    console.log(applicationHeader);
});