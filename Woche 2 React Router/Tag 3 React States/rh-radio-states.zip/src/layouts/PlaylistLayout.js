import React from "react"
import { Outlet } from "react-router-dom"

export default function PlaylistLayout() {
    return (
        <div>
            <h2>Unsere aktuellen Playlists</h2>
            <div className="playlists">
                <Outlet />
            </div>
        </div>
    );
}