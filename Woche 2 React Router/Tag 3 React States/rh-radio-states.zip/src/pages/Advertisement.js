import React, { useState } from "react"

/**
 * Berechnung der Werbepreise.
 * Preis: Anzahl der Sekunden
 * Pauschalbetrag nach Positinierung:
 * Vor Nachricht, Nach Verkehr
 * @returns 
 */
export default function Advertisement() {

    /*
     * Props/States Eigenschaften der aktuellen ReactKomponente
     * Die Props koennen nicht direkt gesetzt werden. Dazu muss
     * der Setter genutzt werden. Das bezeichnet man als Datenkapselung.
     * 
     * Es wird mit der Form ein ViewBinding eingegangen.
     * Das heisst der korrospondierende Wert wird an das
     * Input element mit dem Attribute value gehangen.
     * 
     * Die Werteaktualisierung geht ueber das ReactAttribut onChange
     * des input Elementes (FirePropertyChange). Ist das nicht integriert sind die Felder
     * automatisch ReadOnly. Es kann auch der defaultValue genutzt werden
     * um explizit Felder ReadOnly zu machen. 
     * 
     */
    const [name, setName] = useState("Erika Mustermann")
    const [email, setEmail] = useState("test@beispiel.de")
    const [phoneNr, setPhoneNr] = useState("1234/5678")

    const [advertisementLengthInSeconds, setAdvertisementLengthInSeconds] = useState(1);
    const [advertisementSpot, setAdvertisementSpot] = useState({ beforeNews: false, afterNews: false, beforeTraffic: false });
    const [advertisementPeriod, setAdvertisementPeriod] = useState({ threeTimesDaily: false, sixTimesDaily: false });
    const [advertisementInformation, setAdvertisementInformation] = useState("")

    const taxPricePerScond = 25.0;

    const onAdvertisementFormSubmit = (submitEvent) => {
        submitEvent.preventDefault()

        setAdvertisementInformation(`Ihre Daten: ${name}, ${email}, ${phoneNr}`)
    }

    return (
        <div className="advertisement-wrapper">
            <h2>Berechnen Sie sich Ihre Werbekosten</h2>
            <p>Es ist gar nicht so teuer wie Sie annehmen.</p>

            <div className="advertisement-form">
                <form onSubmit={onAdvertisementFormSubmit}>
                    <label>Name:</label><br></br>
                    <input type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                    /><br></br>

                    <label>Email:</label><br></br>
                    <input type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    /><br></br>

                    <label>Telefon:</label><br></br>
                    <input type="tel"
                        value={phoneNr}
                        onChange={(e) => setPhoneNr(e.target.value)}
                        required
                    /><br></br>

                    <button type="submit"><strong>Unverbindlich</strong> berechnen</button>
                </form>
            </div>
            <div className="advertisement-information">
                {advertisementInformation}
            </div>

        </div>
    );

}