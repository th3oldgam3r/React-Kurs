import React from "react"

/**
 * Gesamter Inhalt der Playlistseite
 * @returns 
 */
export default function Playlists() {
    return (
        <>
            <div className="playlist">
                <ul>
                    <li>Samy Deluxe: Weck mich auf</li>
                    <li>Eminem: The Real Slim Shady</li>
                    <li>Asking Alexandria: The Final Episode</li>
                </ul>
            </div>
            <div className="playlist">
                <ul>
                    <li>AC/DC: Back in Black</li>
                    <li>Deep Purple: Smoke on the Water</li>
                    <li>Guns N' Roses: Welcome to the Jungle</li>
                </ul>
            </div>
            <div className="playlist">
                <ul>
                    <li>PUR: Freunde</li>
                    <li>Wir sind Helden: Denkmal</li>
                    <li>Julie: Die Perfekte Welle</li>
                </ul>
            </div>
        </>


    );
}