//ReactRouter Imports
import {
  createBrowserRouter,
  createRoutesFromElements,
  Route,
  RouterProvider
} from "react-router-dom"

//Styles
import '../styles/app.css';

//Layouts
import RootLayout from "../layouts/RootLayout";
import PlaylistLayout from "../layouts/PlaylistLayout";

//Pages
import Welcome from "../pages/Welcome";
import Error from "../pages/errors/Error";
import Employees from "../pages/Employees";
import NotFound from "../pages/NotFound";
import Playlists from "../pages/Playlists";
import Advertisement from "../pages/Advertisement";

/**
 * Da React eine SPA (Single Page Application) ist,
 * ist es standard-maessig nicht moeglich neue Anfragen
 * an den Webserver zu schicken da alle Informationen
 * beim Aufruf als eine HTML-Seite zurueck geliefert werden.
 * Da Internetseiten aber seltenst nur aus einer Seite
 * stehen bietet die Erweiterung react-router-dom die Moeglichkeit
 * neue Anfragen(z.B.) druch klicken auf Links abzufangen und direkt
 * beim Client/User zu verarbeiten und nicht eine erneute Anfrage
 * an den Webserver zu senden.
 * 
 * Hier werden alle Routes / Routen definiert
 * diese koennen auch geschaltet sein. Wichtig
 * dabei ist das der Pfad in der Root-Route Tag
 * richtig gesetzt wird. Weil alle Kindrouten sich
 * in Relation zu diesem Pfad befinden. Es werden
 * auch automatisch Slashes eingefuegt.
 * Jeder "Neue" - Seite oder besser gesagt jeder
 * neuer Inhalt sollte zu erst hier definiert werden.
 * Ein im Pfad ist eine Catch-All Link. Wenn keine
 * der Routes oben zu trifft wird die Seite "NoteFound" angezeigt.
 * 
 * Steps zum Routing:
 * 1. npm install react-router-dom
 * 2. Ordner Layouts erstellen
 * 3. RootLayout erstellen und die Hauptstruktur der Seite dort integrieren und das Outlet im Main Tag definieren
 * 4. Pages Order und passende Seiten generieren
 * 5. router Objekt in App.js erstellen und konfigurieren.
 * 6. RouterProvider in App.js zurueckgeben
 * 7. styles Ordner  alle CSS-Dateien
 * 8. Routs App.js
 * 
 * Portierung:
 * Welcome == Startseite mit News und Bei uns Werben
 * Employees == Mitarbeiter
 * NotFound == Wenn eine URL angefragt wird die nicht existiert wird diese Seite aufgerufen.
 * errors == Error wird immer dann aufgerufen wenn ein Servefehler auftritt
 */
const router = createBrowserRouter(
  createRoutesFromElements(

    <Route path="/" element={<RootLayout />} errorElement={<Error />}>

      <Route index element={<Welcome />} />


      <Route path="playlist" element={<PlaylistLayout />}>
        <Route index element={<Playlists />} />
      </Route>

      <Route path="advertisement" element={<Advertisement />} />

      <Route path="employees" element={<Employees />} />

      <Route path="*" element={<NotFound />} />
    </Route>
  )
)

function App() {
  return (
    <RouterProvider router={router} />
  );
}

export default App;