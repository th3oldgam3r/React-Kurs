import React, { useState } from "react"

/**
 * Berechnung der Werbepreise.
 * Preis: Anzahl der Sekunden
 * Pauschalbetrag nach Positinierung:
 * Vor Nachricht, Nach Verkehr
 * @returns 
 */
export default function Advertisement() {

    /*
     * Props/States Eigenschaften der aktuellen ReactKomponente
     * Die Props koennen nicht direkt gesetzt werden. Dazu muss
     * der Setter genutzt werden. Das bezeichnet man als Datenkapselung.
     * 
     * Es wird mit der Form ein ViewBinding eingegangen.
     * Das heisst der korrospondierende Wert wird an das
     * Input element mit dem Attribute value gehangen.
     * 
     * Die Werteaktualisierung geht ueber das ReactAttribut onChange
     * des input Elementes (FirePropertyChange). Ist das nicht integriert sind die Felder
     * automatisch ReadOnly. Es kann auch der defaultValue genutzt werden
     * um explizit Felder ReadOnly zu machen. 
     * 
     */
    const [name, setName] = useState("Erika Mustermann")
    const [email, setEmail] = useState("test@beispiel.de")
    const [phoneNr, setPhoneNr] = useState("1234/5678")

    const [advertisementLengthInSeconds, setAdvertisementLengthInSeconds] = useState(20);

    const [advertisementSpotBeforeNews, setAdvertisementSpotBeforeNews] = useState(false);
    const [advertisementSpotAfterNews, setAdvertisementSpotAfterNews] = useState(false);
    const [advertisementSpotTrafficNews, setAdvertisementSpotTrafficNews] = useState(false);

    const [advertisementPeriodThreeTimesDaily, setAdvertisementPeriodThreeTimesDaily] = useState(false);
    const [advertisementPeriodSixTimesDaily, setAdvertisementPeriodSixTimesDaily] = useState(false);

    const [advertisementInformation, setAdvertisementInformation] = useState("")

    const taxPricePerScond = 25.0

    const taxPriceSpotBeforeNews = 150.0
    const taxPriceSpotAfterNews = 130.0
    const taxPriceSpotTrafficNews = 120.0

    const taxPricePeriodThreeTimesDaily = 150.0
    const taxPricePeriodSixTimesDaily = 250.0


    const onAdvertisementFormSubmit = (submitEvent) => {
        submitEvent.preventDefault()

        var baseTaxPrice = (advertisementLengthInSeconds * taxPricePerScond)
        var spotTaxPrice = 0;

        if (advertisementSpotBeforeNews) {
            spotTaxPrice += taxPriceSpotBeforeNews
        }

        if (advertisementSpotAfterNews) {
            spotTaxPrice += taxPriceSpotAfterNews
        }

        if (advertisementSpotTrafficNews) {
            spotTaxPrice += taxPriceSpotTrafficNews
        }

        if (advertisementPeriodThreeTimesDaily) {
            spotTaxPrice += taxPricePeriodThreeTimesDaily
        }

        if (advertisementPeriodSixTimesDaily) {
            spotTaxPrice += taxPricePeriodSixTimesDaily
        }

        var taxPrice = baseTaxPrice + spotTaxPrice;

        setAdvertisementInformation(`${taxPrice} €/Monat`)
    }

    return (
        <div className="advertisement-wrapper">
            <h2>Berechnen Sie sich Ihre Werbekosten</h2>
            <p>Es ist gar nicht so teuer wie Sie annehmen.</p>

            <div className="advertisement-form">
                <form onSubmit={onAdvertisementFormSubmit}>
                    <label>Name:</label><br></br>
                    <input type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                    /><br></br>

                    <label>Email:</label><br></br>
                    <input type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    /><br></br>

                    <label>Telefon:</label><br></br>
                    <input type="tel"
                        value={phoneNr}
                        onChange={(e) => setPhoneNr(e.target.value)}
                        required
                    /><br></br>

                    <label>Spotlänge: {advertisementLengthInSeconds}s:</label><br></br>
                    <input type="range"
                        min="2"
                        max="90"
                        value={advertisementLengthInSeconds}
                        onInput={(e) => setAdvertisementLengthInSeconds(e.target.value)}
                    /><br></br>

                    <label>
                        <input
                            type="checkbox"
                            defaultChecked={advertisementSpotBeforeNews}
                            onChange={() => setAdvertisementSpotBeforeNews(!advertisementSpotBeforeNews)}
                        />Vor den Nachrichten
                    </label><br></br>

                    <label>
                        <input
                            type="checkbox"
                            defaultChecked={advertisementSpotAfterNews}
                            onChange={() => setAdvertisementSpotAfterNews(!advertisementSpotAfterNews)}
                        />Nach den Nachrichten
                    </label><br></br>


                    <label>
                        <input
                            type="checkbox"
                            defaultChecked={advertisementSpotTrafficNews}
                            onChange={() => setAdvertisementSpotTrafficNews(!advertisementSpotTrafficNews)}
                        />Verkehrsnachrichten
                    </label><br></br>


                    <label>
                        <input
                            type="checkbox"
                            value={advertisementPeriodThreeTimesDaily}
                            onChange={() => setAdvertisementPeriodThreeTimesDaily(!advertisementPeriodThreeTimesDaily)}
                        />3 x täglich
                    </label><br></br>

                    <label>
                        <input
                            type="checkbox"
                            defaultChecked={advertisementPeriodSixTimesDaily}
                            onChange={() => setAdvertisementPeriodSixTimesDaily(!advertisementPeriodSixTimesDaily)}
                        />6 x täglich
                    </label><br></br>

                    <button type="submit"><strong>Unverbindlich</strong> berechnen</button>
                </form>
            </div>
            <div className="advertisement-information">
                Ihr Preis: {advertisementInformation}
            </div>

        </div>
    );

}